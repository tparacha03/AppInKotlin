package com.example.todo

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.example.todo.databinding.FragmentAddTaskBinding

class AddTaskFragment : Fragment() {

    private var _binding: FragmentAddTaskBinding? = null
    private val binding get() = _binding!!
    private val taskViewModel: TaskViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        // Inflate the layout and initialize ViewBinding
        _binding = FragmentAddTaskBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Set OnClickListener for the save button
        binding.buttonSaveTask.setOnClickListener {
            val title = binding.editTextTaskTitle.text.toString()
            val deadline = binding.editTextTaskDeadline.text.toString().takeIf { it.isNotBlank() }
            if (title.isNotBlank()) {
                val task = Task(title, deadline)
                taskViewModel.addTask(task)
                parentFragmentManager.popBackStack()  // Go back to previous screen
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null // Clean up to avoid memory leaks
    }
}

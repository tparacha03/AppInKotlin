package com.example.todo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class Task(val title: String, val deadline: String?)

class TaskAdapter : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    // List to hold tasks
    private val tasks = mutableListOf<Task>()

    // Update the task list and notify RecyclerView
    fun updateTasks(newTasks: List<Task>) {
        tasks.clear()
        tasks.addAll(newTasks)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_2, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = tasks[position]
        holder.title.text = task.title
        holder.deadline.text = task.deadline ?: "No Deadline"
    }

    override fun getItemCount(): Int = tasks.size

    // ViewHolder for each task item
    inner class TaskViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(android.R.id.text1)
        val deadline: TextView = view.findViewById(android.R.id.text2)
    }
}
